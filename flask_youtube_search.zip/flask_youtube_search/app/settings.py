import os

YOUTUBE_API_KEY = os.environ.get('YOUTUBE_API_KEY')